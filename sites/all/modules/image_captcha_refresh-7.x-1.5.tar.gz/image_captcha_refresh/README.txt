Readme file for the Image CAPTCHA Refresh module for Drupal
---------------------------------------------

Installation:
  Installation is like with all normal drupal modules:
  extract the 'image_captcha_refresh' folder from the tar ball to the
  modules directory from your website (typically sites/all/modules).

Dependencies:
  Image CAPTCHA Refresh has Image CAPTCHA module in dependence, which is a submodule of the module CAPTCHA.

Configuration:
  The configuration page is at admin/config/people/captcha,
  where you can configure the CAPTCHA module
  and enable the image CAPTCHA for the desired forms.

Author
------
Dmitry Drozdik
dmitry.drozdik@gmail.com